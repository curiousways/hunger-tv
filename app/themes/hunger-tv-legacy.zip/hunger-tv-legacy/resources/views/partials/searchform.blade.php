
<form role="search" method="get" id="searchform" action="@php echo home_url( '/' ); @endphp">
    <div><label class="screen-reader-text" for="s">Search for:</label>
        <input type="text" value="" placeholder="Type. Hit return. Easy." name="s" id="s" />
        <input type="submit" id="searchsubmit" value="Search" />
    </div>
</form>

