@php
global $post;
<time class="updated" datetime="{{ get_post_time('c', true) }}">{{ get_the_date() }}</time>
