<div>
<div class="row">
<div class="col-md-10 offset-md-4">
  <h3 class="light sub">Five of the best stories in your inbox, every week.</h3>
</div>
</div>
  <form action="https://hungertv.us5.list-manage.com/subscribe" method="GET">
    <div class="row">
      <div class="col-md-4 offset-md-4">
    <input type="text" name="MERGE1" placeholder="Name *" class="name" />
</div>
<div class="col-md-6">
    <input type="text" name="MERGE0" placeholder="Email *" class="email"/>
</div>
</div>
<div class="row">
<div class="col-md-8 offset-md-4">
<div class="checkbox">
  <label>
  <input type="checkbox" name="Terms." />
     <i class="helper"></i>I consent to joining the Hunger mailing list. <a href="">Read more</a>
  </label>
</div>
</div>
<div class="col-md-2">
  <input type="hidden" name="u" value="dfaed807bb259c614199d67a0" />
  <input type="hidden" name="id" value="1b5d9b1f65" />
    <input type="submit" value="SUBMIT"  />
</div>
</div>
</form>
</div>
