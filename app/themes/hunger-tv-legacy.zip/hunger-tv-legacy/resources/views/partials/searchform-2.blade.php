
<form role="search" method="get" id="searchform-2" action="@php echo home_url( '/' ); @endphp">
    <div><label class="screen-reader-text" for="s">Search</label>
        <input type="submit" id="searchsubmit-2" class="mobile-search-submit" value="Search" />
        <input type="text" value="" placeholder="Search" name="s" id="s" />
    </div>
</form>

